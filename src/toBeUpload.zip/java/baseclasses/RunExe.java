package baseclasses;

import java.util.HashMap;

import reportGeneration.Logging;

public class RunExe extends Logging{
	
	public static void killBrowser()
	{
		try {
			Runtime.getRuntime().exec("taskkill /f /im chromedriver.exe");
			logger1.info("All Previous active drivers have killed successfully");
			//Logging.ReportLogger.log(Status.PASS, "All Previous active drivers have killed successfully");
			PublicContext.ConsolidatedReportforall=new HashMap<String, String>();
			ReadProerties.getObjectRepository("./PageElements");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
