package webServiceHandle;

import java.util.ArrayList;

public class CallWebService {

	public static void main(String[] args) {
		String  getServicePath = "abc.call";
		String postServicePath = "abc.call";
		
		ArrayList<Integer> value=new ArrayList<Integer>();
		value.add(1);
		value.add(2);
		value.add(3);
		value.add(4);
		value.add(5);
		value.add(6);
		value.add(7);
		value.add(8);
		
		value.forEach((i)-> System.out.print(value.get(i-1)+","));
		//WebServiceAPI.response("RequestString", "RequestFileName", "ResponseFileName", "FileType");
		
	}

}
