package valuevalidatoin;

import java.io.File;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.aventstack.extentreports.Status;

import baseclasses.PublicContext;
import reportGeneration.Logging;

public class testing {
	public static void main(String[] arg){

		System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+File.separator+"Driver"+File.separator+"chromedriver.exe");
		WebDriver driver =new ChromeDriver();
		driver.get("file:///C:/Ankit/Mortgage_URLs%20-%20Devls.html");
		List<WebElement> ankit = driver.findElements(By.tagName("a"));
		
		Logging.logger1.info("size"+ankit.size());
		PublicContext.ReportLogger.log(Status.PASS, "size"+ankit.size());

			for(int i=0;i<ankit.size();i++)
			{
				Logging.logger1.info(ankit.get(i));//.findElement(By.xpath("../../td[1]"))
				Logging.logger1.info(ankit.get(i).getAttribute("href")+"----------------"+ankit.get(i).getText());
			}

	}
}
